import { Toy, CategoryInfo, FestivalInfo, AgeFilter } from '@/types/toy';

export const mockToys: Toy[] = [
  {
    id: '1',
    name: 'Water Gun X200 - Holi Special',
    description: 'High-capacity water blaster perfect for Holi celebrations. BPA-free plastic construction.',
    price: 899,
    images: [
      'https://images.unsplash.com/photo-1523755231516-e43fd2e8dca5?w=400&h=400&fit=crop'
    ],
    category: 'outdoor',
    age_range: { min: 4, max: 10, warning: 'Adult supervision recommended' },
    festivals: ['holi', 'summer'],
    attributes: {
      material: 'BPA-free plastic',
      safety_rating: 4.8,
      educational_value: ['coordination', 'outdoor-play']
    },
    in_stock: true,
    featured: true,
    created_at: '2024-03-01'
  },
  {
    id: '2',
    name: 'Electric LED Racing Car',
    description: 'Remote-controlled racing car with LED lights and sound effects. Perfect for kids who love vehicles.',
    price: 2499,
    images: [
      'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=400&fit=crop'
    ],
    category: 'vehicles',
    age_range: { min: 5, max: 12 },
    festivals: ['birthday', 'diwali'],
    attributes: {
      material: 'ABS plastic',
      battery: '4 AA batteries',
      safety_rating: 4.5,
      educational_value: ['motor-skills', 'coordination']
    },
    in_stock: true,
    featured: false,
    created_at: '2024-02-15'
  },
  {
    id: '3',
    name: 'Educational STEM Building Blocks',
    description: 'Colorful building blocks that teach basic engineering and creativity. 150 pieces included.',
    price: 1599,
    images: [
      'https://images.unsplash.com/photo-1558060370-d644479cb6f7?w=400&h=400&fit=crop'
    ],
    category: 'building',
    age_range: { min: 3, max: 8 },
    festivals: ['birthday', 'christmas'],
    attributes: {
      material: 'Non-toxic ABS plastic',
      safety_rating: 4.9,
      educational_value: ['problem-solving', 'creativity', 'fine-motor-skills']
    },
    in_stock: true,
    featured: true,
    created_at: '2024-01-20'
  },
  {
    id: '4',
    name: 'Teddy Bear - Soft & Cuddly',
    description: 'Premium quality teddy bear made with hypoallergenic materials. Perfect companion for kids.',
    price: 799,
    images: [
      'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=400&fit=crop'
    ],
    category: 'plush',
    age_range: { min: 0, max: 10 },
    festivals: ['birthday', 'christmas', 'raksha-bandhan'],
    attributes: {
      material: 'Hypoallergenic polyester',
      safety_rating: 4.7,
      educational_value: ['emotional-development', 'comfort']
    },
    in_stock: true,
    featured: false,
    created_at: '2024-02-10'
  },
  {
    id: '5',
    name: 'Art & Craft Kit Deluxe',
    description: 'Complete art set with crayons, paints, brushes, and drawing paper. Unleash creativity!',
    price: 1299,
    images: [
      'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400&h=400&fit=crop'
    ],
    category: 'creative',
    age_range: { min: 4, max: 12 },
    festivals: ['birthday', 'diwali'],
    attributes: {
      material: 'Non-toxic materials',
      safety_rating: 4.6,
      educational_value: ['creativity', 'fine-motor-skills', 'artistic-expression']
    },
    in_stock: true,
    featured: true,
    created_at: '2024-03-05'
  },
  {
    id: '6',
    name: 'Electronic Learning Tablet',
    description: 'Kid-friendly tablet with educational games, stories, and learning activities.',
    price: 3999,
    images: [
      'https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=400&h=400&fit=crop'
    ],
    category: 'electronic',
    age_range: { min: 6, max: 14 },
    festivals: ['birthday', 'diwali', 'christmas'],
    attributes: {
      material: 'Durable plastic',
      battery: 'Rechargeable lithium',
      safety_rating: 4.4,
      educational_value: ['literacy', 'numeracy', 'problem-solving']
    },
    in_stock: false,
    featured: false,
    created_at: '2024-01-30'
  }
];

export const ageFilters: AgeFilter[] = [
  { min: 0, max: 2, label: '0-2 years' },
  { min: 3, max: 5, label: '3-5 years' },
  { min: 6, max: 8, label: '6-8 years' },
  { min: 9, max: 12, label: '9-12 years' },
  { min: 13, max: 18, label: '13+ years' }
];

export const categoryInfo: CategoryInfo[] = [
  {
    id: 'vehicles',
    name: 'Vehicles & Transport',
    description: 'Cars, trucks, trains, and all things that move',
    icon: '🚗',
    color: '#FF6B6B',
    subcategories: ['Cars', 'Trucks', 'Trains', 'Planes', 'Boats']
  },
  {
    id: 'educational',
    name: 'Learning & Education',
    description: 'STEM toys that make learning fun',
    icon: '🧠',
    color: '#4ECDC4',
    subcategories: ['Science Kits', 'Math Games', 'Language Learning', 'Coding Toys']
  },
  {
    id: 'creative',
    name: 'Arts & Crafts',
    description: 'Express creativity through art and making',
    icon: '🎨',
    color: '#FFE66D',
    subcategories: ['Drawing', 'Painting', 'Craft Kits', 'Musical Instruments']
  },
  {
    id: 'outdoor',
    name: 'Outdoor Fun',
    description: 'Active toys for outdoor adventures',
    icon: '🏃',
    color: '#95E1D3',
    subcategories: ['Sports Equipment', 'Water Toys', 'Garden Games', 'Bikes & Scooters']
  },
  {
    id: 'electronic',
    name: 'Electronic Toys',
    description: 'High-tech toys with interactive features',
    icon: '🔌',
    color: '#A8E6CF',
    subcategories: ['Tablets', 'Robots', 'Gaming', 'Smart Toys']
  },
  {
    id: 'plush',
    name: 'Plush & Soft Toys',
    description: 'Cuddly companions for comfort and play',
    icon: '🧸',
    color: '#FFB3E6',
    subcategories: ['Teddy Bears', 'Animals', 'Dolls', 'Character Plush']
  }
];

export const festivalInfo: FestivalInfo[] = [
  {
    id: 'holi',
    name: 'Holi',
    emoji: '🎨',
    description: 'Festival of Colors',
    season: 'Spring',
    typical_months: [3, 4],
    colors: ['#FF69B4', '#00CED1', '#32CD32', '#FFD700']
  },
  {
    id: 'diwali',
    name: 'Diwali',
    emoji: '🪔',
    description: 'Festival of Lights',
    season: 'Autumn',
    typical_months: [10, 11],
    colors: ['#FFD700', '#FF8C00', '#FF6B47']
  },
  {
    id: 'christmas',
    name: 'Christmas',
    emoji: '🎄',
    description: 'Season of Giving',
    season: 'Winter',
    typical_months: [12],
    colors: ['#DC143C', '#228B22', '#FFD700']
  },
  {
    id: 'birthday',
    name: 'Birthday',
    emoji: '🎂',
    description: 'Special Day Celebration',
    season: 'All Year',
    typical_months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    colors: ['#FF69B4', '#87CEEB', '#98FB98', '#DDA0DD']
  },
  {
    id: 'summer',
    name: 'Summer Fun',
    emoji: '☀️',
    description: 'Hot Weather Activities',
    season: 'Summer',
    typical_months: [4, 5, 6, 7],
    colors: ['#FFD700', '#FF6347', '#00CED1']
  }
];