"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useToyStore } from '@/store/toyStore';
import { ageFilters } from '@/data/mockData';
import { AgeFilter } from '@/types/toy';

export default function AgeSelector() {
  const { selectedAge, setAgeFilter } = useToyStore();
  const [isExpanded, setIsExpanded] = useState(false);

  console.log('AgeSelector render - selectedAge:', selectedAge);

  const handleAgeSelect = (age: AgeFilter) => {
    console.log('Age selected:', age);
    setAgeFilter(selectedAge?.label === age.label ? null : age);
    setIsExpanded(false);
  };

  return (
    <div className="floating-toolbar">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-gray-700">Find toys for:</span>
          <motion.button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-coral-500 to-mint-500 text-white rounded-full text-sm font-medium shadow-sm hover:shadow-md transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <span className="text-lg">👶</span>
            <span>{selectedAge ? selectedAge.label : 'All ages'}</span>
            <motion.span
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
            >
              ▼
            </motion.span>
          </motion.button>
        </div>

        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 mt-2 bg-white rounded-toy shadow-toy border border-gray-200 p-4 z-50"
          >
            <div className="grid grid-cols-5 gap-2">
              {ageFilters.map((age) => (
                <motion.button
                  key={age.label}
                  onClick={() => handleAgeSelect(age)}
                  className={`px-3 py-2 rounded-full text-xs font-medium transition-all ${
                    selectedAge?.label === age.label
                      ? 'bg-coral-500 text-white shadow-md'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {age.label}
                </motion.button>
              ))}
            </div>
            
            <div className="mt-4 pt-3 border-t border-gray-100">
              <motion.button
                onClick={() => handleAgeSelect({ min: 0, max: 18, label: 'All ages' })}
                className="text-xs text-gray-500 hover:text-gray-700 transition-colors"
                whileHover={{ scale: 1.02 }}
              >
                Clear age filter
              </motion.button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}