"use client";

import { motion } from 'framer-motion';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import { Toy } from '@/types/toy';
import { useToyStore } from '@/store/toyStore';
import { festivalInfo } from '@/data/mockData';

interface ToyCardProps {
  toy: Toy;
  index?: number;
}

export default function ToyCard({ toy, index = 0 }: ToyCardProps) {
  const { cartItems, addToCart, removeFromCart } = useToyStore();
  const isInCart = cartItems.includes(toy.id);

  console.log('ToyCard render:', toy.name, 'inCart:', isInCart);

  const handleCartToggle = () => {
    console.log('Cart toggle for toy:', toy.id);
    if (isInCart) {
      removeFromCart(toy.id);
    } else {
      addToCart(toy.id);
    }
  };

  const currentFestival = toy.festivals.find(festival => {
    const festivalData = festivalInfo.find(f => f.id === festival);
    const currentMonth = new Date().getMonth() + 1;
    return festivalData?.typical_months.includes(currentMonth);
  });

  const festivalData = currentFestival ? festivalInfo.find(f => f.id === currentFestival) : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="toy-card group relative"
      whileHover={{ y: -8 }}
    >
      {/* Festival badge */}
      {festivalData && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute top-3 left-3 z-10 px-2 py-1 bg-gradient-to-r from-yellow-400 to-orange-400 text-white text-xs font-medium rounded-full shadow-lg"
        >
          {festivalData.emoji} Perfect for {festivalData.name}!
        </motion.div>
      )}

      {/* Featured badge */}
      {toy.featured && (
        <div className="absolute top-3 right-3 z-10 px-2 py-1 bg-gradient-to-r from-coral-500 to-mint-500 text-white text-xs font-bold rounded-full">
          ⭐ Featured
        </div>
      )}

      {/* Image container */}
      <div className="relative overflow-hidden rounded-t-toy h-48 bg-gray-100">
        <img
          src={toy.images[0]}
          alt={toy.name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
        
        {/* Overlay actions */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileHover={{ opacity: 1, scale: 1 }}
            className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          >
            <button className="p-2 bg-white/90 rounded-full shadow-lg hover:bg-white mr-2">
              <Heart className="w-5 h-5 text-gray-700" />
            </button>
          </motion.div>
        </div>

        {/* Stock status */}
        {!toy.in_stock && (
          <div className="absolute inset-0 bg-gray-900/50 flex items-center justify-center">
            <span className="px-3 py-1 bg-gray-800 text-white text-sm font-medium rounded-full">
              Out of Stock
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Age badge */}
        <div className="age-badge mb-3">
          🪀 Ages {toy.age_range.min}-{toy.age_range.max}
          {toy.age_range.warning && (
            <span className="ml-1 text-yellow-300">⚠️</span>
          )}
        </div>

        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-coral-600 transition-colors">
          {toy.name}
        </h3>

        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {toy.description}
        </p>

        {/* Educational value tags */}
        {toy.attributes.educational_value && (
          <div className="flex flex-wrap gap-1 mb-3">
            {toy.attributes.educational_value.slice(0, 2).map((value) => (
              <span
                key={value}
                className="px-2 py-1 bg-mint-100 text-mint-700 text-xs rounded-full"
              >
                {value.replace('-', ' ')}
              </span>
            ))}
          </div>
        )}

        {/* Rating and price */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-medium text-gray-700">
              {toy.attributes.safety_rating}
            </span>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold text-gray-900">₹{toy.price}</span>
          </div>
        </div>

        {/* Add to cart button */}
        <motion.button
          onClick={handleCartToggle}
          disabled={!toy.in_stock}
          className={`w-full py-3 rounded-full font-medium transition-all flex items-center justify-center gap-2 ${
            isInCart
              ? 'bg-green-500 text-white'
              : toy.in_stock
              ? 'bg-gradient-to-r from-coral-500 to-mint-500 text-white hover:shadow-lg'
              : 'bg-gray-200 text-gray-500 cursor-not-allowed'
          }`}
          whileHover={toy.in_stock ? { scale: 1.02 } : {}}
          whileTap={toy.in_stock ? { scale: 0.98 } : {}}
        >
          <ShoppingCart className="w-4 h-4" />
          {isInCart ? 'Added to Cart' : toy.in_stock ? 'Add to Cart' : 'Out of Stock'}
        </motion.button>
      </div>
    </motion.div>
  );
}