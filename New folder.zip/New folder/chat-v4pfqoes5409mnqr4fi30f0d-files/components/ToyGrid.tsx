"use client";

import { useToyStore } from '@/store/toyStore';
import ToyCard from './ToyCard';
import { motion } from 'framer-motion';

export default function ToyGrid() {
  const { filteredToys, isLoading } = useToyStore();

  console.log('ToyGrid render - filteredToys:', filteredToys.length, 'isLoading:', isLoading);

  if (isLoading) {
    return (
      <div className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="toy-card animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-toy"></div>
                <div className="p-4">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="h-10 bg-gray-200 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (filteredToys.length === 0) {
    return (
      <div className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="py-12"
          >
            <div className="text-8xl mb-6">🔍</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              No toys found
            </h3>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              We couldn't find any toys matching your current filters. 
              Try adjusting your age range or removing some filters.
            </p>
            <motion.button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-gradient-to-r from-coral-500 to-mint-500 text-white rounded-full font-medium hover:shadow-lg transition-shadow"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Reset Filters
            </motion.button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <section className="py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Recommended Toys
          </h2>
          <p className="text-gray-600">
            Showing {filteredToys.length} toy{filteredToys.length !== 1 ? 's' : ''} 
            {filteredToys.length > 0 && ' perfect for your selection'}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredToys.map((toy, index) => (
            <ToyCard 
              key={toy.id} 
              toy={toy} 
              index={index}
            />
          ))}
        </div>

        {/* Load more button (for future pagination) */}
        {filteredToys.length >= 8 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-12 text-center"
          >
            <motion.button
              className="px-8 py-3 bg-gray-100 text-gray-700 rounded-full font-medium hover:bg-gray-200 transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Load More Toys
            </motion.button>
          </motion.div>
        )}
      </div>
    </section>
  );
}