"use client";

import { motion } from 'framer-motion';
import { Search, ShoppingCart, User, Heart } from 'lucide-react';
import { useToyStore } from '@/store/toyStore';

export default function Header() {
  const { searchQuery, setSearchQuery, cartItems } = useToyStore();

  console.log('Header render - cartItems:', cartItems.length);

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200/50 shadow-sm"
    >
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-3"
            whileHover={{ scale: 1.02 }}
          >
            <div className="w-10 h-10 bg-gradient-to-r from-coral-500 to-mint-500 rounded-xl flex items-center justify-center text-white font-bold text-lg">
              🧸
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-coral-500 to-mint-500 bg-clip-text text-transparent">
                ToySpark Pro
              </h1>
              <p className="text-xs text-gray-600">AI-Driven Toy Discovery</p>
            </div>
          </motion.div>

          {/* Search bar */}
          <div className="flex-1 max-w-2xl mx-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search toys by name, age, or festival..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-coral-500/20 focus:border-coral-500 transition-all"
              />
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-4">
            <motion.button
              className="p-2 text-gray-600 hover:text-coral-500 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Heart className="w-6 h-6" />
            </motion.button>

            <motion.button
              className="relative p-2 text-gray-600 hover:text-coral-500 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ShoppingCart className="w-6 h-6" />
              {cartItems.length > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 w-5 h-5 bg-coral-500 text-white text-xs rounded-full flex items-center justify-center font-medium"
                >
                  {cartItems.length}
                </motion.span>
              )}
            </motion.button>

            <motion.button
              className="p-2 text-gray-600 hover:text-coral-500 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <User className="w-6 h-6" />
            </motion.button>
          </div>
        </div>
      </div>
    </motion.header>
  );
}