"use client";

import { motion } from 'framer-motion';
import { useToyStore } from '@/store/toyStore';
import { categoryInfo } from '@/data/mockData';
import { ToyCategory } from '@/types/toy';

export default function CategoryGrid() {
  const { selectedCategories, addCategoryFilter, removeCategoryFilter } = useToyStore();

  console.log('CategoryGrid render - selectedCategories:', selectedCategories);

  const handleCategoryClick = (category: ToyCategory) => {
    console.log('Category clicked:', category);
    if (selectedCategories.includes(category)) {
      removeCategoryFilter(category);
    } else {
      addCategoryFilter(category);
    }
  };

  return (
    <section className="py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Explore Toy Categories
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover the perfect toys organized by play style and learning goals
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categoryInfo.map((category, index) => {
            const isSelected = selectedCategories.includes(category.id);
            
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`category-box relative overflow-hidden cursor-pointer ${
                  isSelected ? 'ring-2 ring-coral-500 bg-coral-50' : ''
                }`}
                onClick={() => handleCategoryClick(category.id)}
                whileHover={{ 
                  scale: 1.02,
                  rotateX: 2,
                  rotateY: -2,
                }}
                whileTap={{ scale: 0.98 }}
                style={{
                  transformStyle: 'preserve-3d',
                }}
              >
                {/* Background gradient based on category color */}
                <div 
                  className="absolute inset-0 opacity-5"
                  style={{ 
                    background: `linear-gradient(135deg, ${category.color}20, ${category.color}10)` 
                  }}
                />
                
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-4">
                    <div 
                      className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-lg"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      {category.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-1">
                        {category.name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {category.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {category.subcategories.slice(0, 3).map((sub) => (
                      <span
                        key={sub}
                        className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium"
                      >
                        {sub}
                      </span>
                    ))}
                    {category.subcategories.length > 3 && (
                      <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
                        +{category.subcategories.length - 3} more
                      </span>
                    )}
                  </div>

                  {isSelected && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-4 right-4 w-8 h-8 bg-coral-500 rounded-full flex items-center justify-center text-white text-sm font-bold"
                    >
                      ✓
                    </motion.div>
                  )}
                </div>

                {/* 3D effect overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-black/5 pointer-events-none" />
              </motion.div>
            );
          })}
        </div>

        {selectedCategories.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 text-center"
          >
            <p className="text-gray-600">
              Showing toys for: {' '}
              <span className="font-medium text-coral-600">
                {selectedCategories.map(cat => 
                  categoryInfo.find(c => c.id === cat)?.name
                ).join(', ')}
              </span>
            </p>
          </motion.div>
        )}
      </div>
    </section>
  );
}