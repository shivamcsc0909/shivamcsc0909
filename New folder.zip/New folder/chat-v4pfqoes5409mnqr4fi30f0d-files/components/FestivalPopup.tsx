"use client";

import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useToyStore } from '@/store/toyStore';
import { festivalInfo } from '@/data/mockData';

export default function FestivalPopup() {
  const { currentFestivalPopup, hideFestivalPopup, addFestivalFilter } = useToyStore();

  console.log('FestivalPopup render - currentFestivalPopup:', currentFestivalPopup);

  useEffect(() => {
    if (currentFestivalPopup) {
      // Auto-hide popup after 10 seconds
      const timer = setTimeout(() => {
        hideFestivalPopup();
      }, 10000);

      return () => clearTimeout(timer);
    }
  }, [currentFestivalPopup, hideFestivalPopup]);

  const festivalData = currentFestivalPopup 
    ? festivalInfo.find(f => f.id === currentFestivalPopup)
    : null;

  if (!festivalData) return null;

  const handleShopNow = () => {
    console.log('Shop now clicked for festival:', currentFestivalPopup);
    if (currentFestivalPopup) {
      addFestivalFilter(currentFestivalPopup);
    }
    hideFestivalPopup();
  };

  const handleRemindLater = () => {
    console.log('Remind later clicked');
    hideFestivalPopup();
    // In a real app, this would set a reminder
  };

  return (
    <AnimatePresence>
      {currentFestivalPopup && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="festival-popup"
          style={{ zIndex: 9999 }}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ 
              type: 'spring', 
              stiffness: 300, 
              damping: 25 
            }}
            className="festival-content relative overflow-hidden"
            style={{
              background: `linear-gradient(135deg, ${festivalData.colors[0]}15, ${festivalData.colors[1]}15)`
            }}
          >
            {/* Close button */}
            <button
              onClick={hideFestivalPopup}
              className="absolute top-4 right-4 p-1 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
            >
              <X className="w-4 h-4 text-gray-600" />
            </button>

            {/* Animated background elements */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              {festivalData.id === 'diwali' && (
                <>
                  {[...Array(6)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-2 h-2 bg-yellow-400 rounded-full"
                      style={{
                        left: `${20 + i * 15}%`,
                        top: `${10 + (i % 2) * 20}%`,
                      }}
                      animate={{
                        y: [0, -10, 0],
                        opacity: [0.4, 1, 0.4],
                        scale: [0.8, 1.2, 0.8],
                      }}
                      transition={{
                        duration: 2,
                        delay: i * 0.3,
                        repeat: Infinity,
                      }}
                    />
                  ))}
                </>
              )}
              
              {festivalData.id === 'holi' && (
                <>
                  {festivalData.colors.map((color, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-8 h-8 rounded-full opacity-20"
                      style={{
                        backgroundColor: color,
                        left: `${15 + i * 20}%`,
                        top: `${5 + i * 15}%`,
                      }}
                      animate={{
                        scale: [1, 1.5, 1],
                        rotate: [0, 180, 360],
                      }}
                      transition={{
                        duration: 3,
                        delay: i * 0.5,
                        repeat: Infinity,
                      }}
                    />
                  ))}
                </>
              )}
            </div>

            {/* Content */}
            <div className="relative z-10 text-center">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-6xl mb-4"
              >
                {festivalData.emoji}
              </motion.div>

              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                {festivalData.name} Special!
              </h2>

              <p className="text-gray-600 mb-6">
                Discover perfect toys for {festivalData.description.toLowerCase()}. 
                Special collection curated just for this celebration!
              </p>

              <div className="flex gap-3 justify-center">
                <motion.button
                  onClick={handleShopNow}
                  className="px-6 py-3 bg-gradient-to-r from-coral-500 to-mint-500 text-white rounded-full font-medium shadow-lg hover:shadow-xl transition-shadow"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Shop {festivalData.name} Toys
                </motion.button>

                <motion.button
                  onClick={handleRemindLater}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-full font-medium hover:bg-gray-200 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Remind Me Later
                </motion.button>
              </div>

              {/* Auto-close indicator */}
              <div className="mt-4">
                <div className="text-xs text-gray-500 mb-2">Auto-closing in:</div>
                <motion.div
                  className="w-24 h-1 bg-gray-200 rounded-full mx-auto overflow-hidden"
                >
                  <motion.div
                    className="h-full bg-coral-500"
                    initial={{ width: '100%' }}
                    animate={{ width: '0%' }}
                    transition={{ duration: 10, ease: 'linear' }}
                  />
                </motion.div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}