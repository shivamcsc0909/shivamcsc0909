"use client";

import { useEffect } from 'react';
import { useToyStore } from '@/store/toyStore';
import { festivalInfo } from '@/data/mockData';

export function useFestivalDetection() {
  const { showFestivalPopup } = useToyStore();

  useEffect(() => {
    console.log('Festival detection hook initialized');

    const checkForActiveFestivals = () => {
      const currentMonth = new Date().getMonth() + 1;
      const currentDate = new Date().getDate();
      
      console.log('Checking for festivals - current month:', currentMonth, 'date:', currentDate);

      // Find festivals active in current month
      const activeFestivals = festivalInfo.filter(festival => 
        festival.typical_months.includes(currentMonth)
      );

      console.log('Active festivals found:', activeFestivals);

      if (activeFestivals.length > 0) {
        // For demo purposes, show the first active festival
        // In production, this would be more sophisticated with geo-location and user preferences
        const festivalToShow = activeFestivals[0];
        
        // Check if we should show popup (not shown recently)
        const lastShown = localStorage.getItem(`festival_popup_${festivalToShow.id}`);
        const now = Date.now();
        const oneDayMs = 24 * 60 * 60 * 1000;
        
        if (!lastShown || (now - parseInt(lastShown)) > oneDayMs) {
          console.log('Showing festival popup for:', festivalToShow.id);
          
          // Show popup after a brief delay for better UX
          setTimeout(() => {
            showFestivalPopup(festivalToShow.id);
            localStorage.setItem(`festival_popup_${festivalToShow.id}`, now.toString());
          }, 3000);
        } else {
          console.log('Festival popup already shown recently for:', festivalToShow.id);
        }
      }
    };

    // Check immediately
    checkForActiveFestivals();

    // For demo purposes, also trigger specific festivals based on date
    const triggerDemoFestivals = () => {
      const today = new Date();
      const dayOfMonth = today.getDate();

      // Trigger Holi demo if it's between 15th-20th of any month
      if (dayOfMonth >= 15 && dayOfMonth <= 20) {
        console.log('Demo: Triggering Holi festival');
        setTimeout(() => {
          showFestivalPopup('holi');
        }, 5000);
      }
      // Trigger Diwali demo if it's between 5th-10th of any month
      else if (dayOfMonth >= 5 && dayOfMonth <= 10) {
        console.log('Demo: Triggering Diwali festival');
        setTimeout(() => {
          showFestivalPopup('diwali');
        }, 4000);
      }
    };

    // Enable demo mode
    triggerDemoFestivals();

  }, [showFestivalPopup]);

  return null;
}