"use client";

import { useEffect } from 'react';
import { useToyStore } from '@/store/toyStore';
import { mockToys } from '@/data/mockData';
import { useFestivalDetection } from '@/hooks/useFestivalDetection';

import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import AgeSelector from '@/components/AgeSelector';
import CategoryGrid from '@/components/CategoryGrid';
import ToyGrid from '@/components/ToyGrid';
import FestivalPopup from '@/components/FestivalPopup';

export default function Home() {
  const { setToys, setLoading } = useToyStore();

  // Initialize festival detection
  useFestivalDetection();

  useEffect(() => {
    console.log('App initialization - loading mock data');
    setLoading(true);
    
    // Simulate API loading time
    setTimeout(() => {
      setToys(mockToys);
      setLoading(false);
      console.log('Mock data loaded successfully');
    }, 1000);
  }, [setToys, setLoading]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <AgeSelector />
      <HeroSection />
      <CategoryGrid />
      <ToyGrid />
      <FestivalPopup />
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 mt-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-coral-500 to-mint-500 rounded-lg flex items-center justify-center text-white font-bold">
                  🧸
                </div>
                <span className="text-xl font-bold">ToySpark Pro</span>
              </div>
              <p className="text-gray-400 text-sm">
                AI-driven toy discovery platform that makes finding the perfect toys easy and safe.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Shop</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>All Toys</li>
                <li>By Age</li>
                <li>By Category</li>
                <li>Festival Specials</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Help Center</li>
                <li>Safety Guide</li>
                <li>Returns</li>
                <li>Contact Us</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Follow Us</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Instagram</li>
                <li>Facebook</li>
                <li>YouTube</li>
                <li>Twitter</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 ToySpark Pro. All rights reserved. Built with safety and fun in mind.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
