export interface Toy {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  category: ToyCategory;
  age_range: {
    min: number;
    max: number;
    warning?: string;
  };
  festivals: Festival[];
  attributes: {
    material: string;
    battery?: string;
    safety_rating: number;
    educational_value?: string[];
  };
  in_stock: boolean;
  featured: boolean;
  created_at: string;
}

export type ToyCategory = 
  | 'vehicles'
  | 'educational'
  | 'creative'
  | 'outdoor'
  | 'electronic'
  | 'plush'
  | 'building'
  | 'dolls'
  | 'board-games'
  | 'sports';

export type Festival = 
  | 'diwali'
  | 'holi'
  | 'christmas'
  | 'dussehra'
  | 'eid'
  | 'raksha-bandhan'
  | 'birthday'
  | 'summer'
  | 'winter';

export interface AgeFilter {
  min: number;
  max: number;
  label: string;
}

export interface CategoryInfo {
  id: ToyCategory;
  name: string;
  description: string;
  icon: string;
  color: string;
  subcategories: string[];
}

export interface FestivalInfo {
  id: Festival;
  name: string;
  emoji: string;
  description: string;
  season: string;
  typical_months: number[];
  colors: string[];
}