"use client";

import { create } from 'zustand';
import { Toy, AgeFilter, Festival, ToyCategory } from '@/types/toy';

interface ToyStore {
  // State
  toys: Toy[];
  filteredToys: Toy[];
  selectedAge: AgeFilter | null;
  selectedFestivals: Festival[];
  selectedCategories: ToyCategory[];
  searchQuery: string;
  isLoading: boolean;
  currentFestivalPopup: Festival | null;
  cartItems: string[];
  
  // Actions
  setToys: (toys: Toy[]) => void;
  setAgeFilter: (age: AgeFilter | null) => void;
  addFestivalFilter: (festival: Festival) => void;
  removeFestivalFilter: (festival: Festival) => void;
  addCategoryFilter: (category: ToyCategory) => void;
  removeCategoryFilter: (category: ToyCategory) => void;
  setSearchQuery: (query: string) => void;
  filterToys: () => void;
  setLoading: (loading: boolean) => void;
  showFestivalPopup: (festival: Festival) => void;
  hideFestivalPopup: () => void;
  addToCart: (toyId: string) => void;
  removeFromCart: (toyId: string) => void;
  clearFilters: () => void;
}

export const useToyStore = create<ToyStore>((set, get) => ({
  // Initial state
  toys: [],
  filteredToys: [],
  selectedAge: null,
  selectedFestivals: [],
  selectedCategories: [],
  searchQuery: '',
  isLoading: false,
  currentFestivalPopup: null,
  cartItems: [],

  // Actions
  setToys: (toys) => {
    console.log('Setting toys in store:', toys.length);
    set({ toys });
    get().filterToys();
  },

  setAgeFilter: (age) => {
    console.log('Setting age filter:', age);
    set({ selectedAge: age });
    get().filterToys();
  },

  addFestivalFilter: (festival) => {
    const { selectedFestivals } = get();
    if (!selectedFestivals.includes(festival)) {
      console.log('Adding festival filter:', festival);
      set({ selectedFestivals: [...selectedFestivals, festival] });
      get().filterToys();
    }
  },

  removeFestivalFilter: (festival) => {
    console.log('Removing festival filter:', festival);
    const { selectedFestivals } = get();
    set({ selectedFestivals: selectedFestivals.filter(f => f !== festival) });
    get().filterToys();
  },

  addCategoryFilter: (category) => {
    const { selectedCategories } = get();
    if (!selectedCategories.includes(category)) {
      console.log('Adding category filter:', category);
      set({ selectedCategories: [...selectedCategories, category] });
      get().filterToys();
    }
  },

  removeCategoryFilter: (category) => {
    console.log('Removing category filter:', category);
    const { selectedCategories } = get();
    set({ selectedCategories: selectedCategories.filter(c => c !== category) });
    get().filterToys();
  },

  setSearchQuery: (query) => {
    console.log('Setting search query:', query);
    set({ searchQuery: query });
    get().filterToys();
  },

  filterToys: () => {
    const { toys, selectedAge, selectedFestivals, selectedCategories, searchQuery } = get();
    console.log('Filtering toys with:', { selectedAge, selectedFestivals, selectedCategories, searchQuery });
    
    let filtered = [...toys];

    // Age filter
    if (selectedAge) {
      filtered = filtered.filter(toy => 
        toy.age_range.min <= selectedAge.max && toy.age_range.max >= selectedAge.min
      );
    }

    // Festival filter
    if (selectedFestivals.length > 0) {
      filtered = filtered.filter(toy =>
        selectedFestivals.some(festival => toy.festivals.includes(festival))
      );
    }

    // Category filter
    if (selectedCategories.length > 0) {
      filtered = filtered.filter(toy =>
        selectedCategories.includes(toy.category)
      );
    }

    // Search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(toy =>
        toy.name.toLowerCase().includes(query) ||
        toy.description.toLowerCase().includes(query) ||
        toy.category.toLowerCase().includes(query)
      );
    }

    // Sort by safety rating and featured status
    filtered.sort((a, b) => {
      if (a.featured && !b.featured) return -1;
      if (!a.featured && b.featured) return 1;
      return b.attributes.safety_rating - a.attributes.safety_rating;
    });

    console.log('Filtered toys result:', filtered.length);
    set({ filteredToys: filtered });
  },

  setLoading: (loading) => set({ isLoading: loading }),

  showFestivalPopup: (festival) => {
    console.log('Showing festival popup:', festival);
    set({ currentFestivalPopup: festival });
  },

  hideFestivalPopup: () => {
    console.log('Hiding festival popup');
    set({ currentFestivalPopup: null });
  },

  addToCart: (toyId) => {
    const { cartItems } = get();
    if (!cartItems.includes(toyId)) {
      console.log('Adding to cart:', toyId);
      set({ cartItems: [...cartItems, toyId] });
    }
  },

  removeFromCart: (toyId) => {
    console.log('Removing from cart:', toyId);
    const { cartItems } = get();
    set({ cartItems: cartItems.filter(id => id !== toyId) });
  },

  clearFilters: () => {
    console.log('Clearing all filters');
    set({
      selectedAge: null,
      selectedFestivals: [],
      selectedCategories: [],
      searchQuery: ''
    });
    get().filterToys();
  }
}));