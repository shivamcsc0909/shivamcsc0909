import { Header } from "@/components/navigation/header";
import { Hero } from "@/components/sections/hero";
import { ToyFinder } from "@/components/sections/toy-finder";
import { FeaturedProducts } from "@/components/sections/featured-products";
import { FestivalShowcase } from "@/components/sections/festival-showcase";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <ToyFinder />
        <FeaturedProducts />
        <FestivalShowcase />
      </main>
      <Footer />
    </div>
  );
}
