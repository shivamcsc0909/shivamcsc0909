"use client";

import { motion } from "framer-motion";
import { Sparkles, Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function Footer() {
  console.log("Footer component rendering");

  const footerSections = [
    {
      title: "Shop",
      links: [
        { name: "RC Cars", href: "#rc-cars" },
        { name: "STEM Toys", href: "#stem" },
        { name: "Soft Toys", href: "#soft-toys" },
        { name: "Outdoor Games", href: "#outdoor" },
        { name: "Educational Toys", href: "#educational" },
      ],
    },
    {
      title: "Support",
      links: [
        { name: "Age Guide", href: "#age-guide" },
        { name: "Safety Standards", href: "#safety" },
        { name: "Return Policy", href: "#returns" },
        { name: "Warranty", href: "#warranty" },
        { name: "FAQ", href: "#faq" },
      ],
    },
    {
      title: "Company",
      links: [
        { name: "About ToySpark", href: "#about" },
        { name: "Our Manufacturing", href: "#manufacturing" },
        { name: "Quality Promise", href: "#quality" },
        { name: "Careers", href: "#careers" },
        { name: "Press", href: "#press" },
      ],
    },
  ];

  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Youtube, href: "#", label: "YouTube" },
  ];

  const certifications = [
    "🛡️ BIS Certified",
    "🌟 ISO 9001",
    "✅ CE Marked",
    "🔒 COPPA Compliant",
  ];

  return (
    <footer className="bg-gradient-to-b from-background to-muted/20 border-t border-primary/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Brand Section */}
            <motion.div
              className="lg:col-span-2"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              {/* Logo */}
              <div className="flex items-center space-x-2 mb-6">
                <div className="relative">
                  <Sparkles className="h-8 w-8 text-primary animate-pulse" />
                  <div className="absolute inset-0 bg-primary/20 rounded-full blur-md" />
                </div>
                <span className="text-2xl font-bold font-orbitron gradient-text">
                  ToySpark
                </span>
              </div>

              <p className="text-muted-foreground mb-6 max-w-md">
                India's premium toy manufacturer bringing international quality and innovation 
                to every child's playtime. Made with love, tested for safety, designed for joy.
              </p>

              {/* Contact Info */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center text-sm">
                  <Phone className="h-4 w-4 text-primary mr-3" />
                  <span>+91 1800-TOY-SPARK (1800-869-77275)</span>
                </div>
                <div className="flex items-center text-sm">
                  <Mail className="h-4 w-4 text-primary mr-3" />
                  <span>hello@toyspark.in</span>
                </div>
                <div className="flex items-start text-sm">
                  <MapPin className="h-4 w-4 text-primary mr-3 mt-0.5" />
                  <span>Manufacturing Hub: Gujarat, India<br />
                  Corporate Office: Bangalore, Karnataka</span>
                </div>
              </div>

              {/* Certifications */}
              <div>
                <h4 className="font-semibold mb-3 text-sm">Quality Certifications:</h4>
                <div className="flex flex-wrap gap-2">
                  {certifications.map((cert, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {cert}
                    </Badge>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Navigation Sections */}
            {footerSections.map((section, sectionIndex) => (
              <motion.div
                key={section.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: (sectionIndex + 1) * 0.1 }}
              >
                <h3 className="font-semibold mb-6 text-lg">{section.title}</h3>
                <ul className="space-y-3">
                  {section.links.map((link, linkIndex) => (
                    <motion.li key={link.name}>
                      <a
                        href={link.href}
                        className="text-muted-foreground hover:text-primary transition-colors text-sm"
                      >
                        {link.name}
                      </a>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Newsletter Section */}
        <motion.div
          className="py-8 border-t border-primary/10"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-2">
                Stay in the Loop! 📮
              </h3>
              <p className="text-muted-foreground">
                Get the latest toy launches, parenting tips, and exclusive deals delivered to your inbox.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg border border-primary/20 bg-background/50 focus:border-primary focus:outline-none"
              />
              <Button className="shadow-neon">
                <Heart className="mr-2 h-4 w-4" />
                Subscribe
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Bottom Section */}
        <motion.div
          className="py-8 border-t border-primary/10"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
        >
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            {/* Copyright */}
            <div className="text-center md:text-left">
              <p className="text-muted-foreground text-sm">
                © 2025 ToySpark Technologies Pvt. Ltd. All rights reserved.
              </p>
              <p className="text-muted-foreground text-xs mt-1">
                Proudly manufactured in India with international quality standards
              </p>
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    className="p-2 rounded-full glass hover:bg-primary/10 transition-colors"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    whileTap={{ scale: 0.95 }}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <IconComponent className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors" />
                    <span className="sr-only">{social.label}</span>
                  </motion.a>
                );
              })}
            </div>
          </div>

          {/* Legal Links */}
          <div className="mt-6 pt-6 border-t border-primary/10">
            <div className="flex flex-wrap justify-center gap-6 text-xs text-muted-foreground">
              <a href="#privacy" className="hover:text-primary transition-colors">
                Privacy Policy
              </a>
              <a href="#terms" className="hover:text-primary transition-colors">
                Terms of Service
              </a>
              <a href="#shipping" className="hover:text-primary transition-colors">
                Shipping Policy
              </a>
              <a href="#refund" className="hover:text-primary transition-colors">
                Refund Policy
              </a>
              <a href="#cookie" className="hover:text-primary transition-colors">
                Cookie Policy
              </a>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Floating "Made with Love" Badge */}
      <motion.div
        className="fixed bottom-4 right-4 z-40"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 2, duration: 0.5 }}
      >
        <Badge className="glass border-primary/20 animate-pulse">
          Made with <Heart className="w-3 h-3 mx-1 text-red-500 fill-current" /> in India
        </Badge>
      </motion.div>
    </footer>
  );
}