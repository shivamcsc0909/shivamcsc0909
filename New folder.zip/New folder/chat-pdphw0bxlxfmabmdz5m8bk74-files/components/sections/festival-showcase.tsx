"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Gift, Sparkles, Timer, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";

interface Festival {
  id: string;
  name: string;
  emoji: string;
  date: string;
  description: string;
  discount: number;
  color: string;
  bgGradient: string;
  specialOffers: string[];
  countdownDate: Date;
}

export function FestivalShowcase() {
  const [timeLeft, setTimeLeft] = useState<{[key: string]: {
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }}>({});

  console.log("FestivalShowcase component rendering");

  const festivals: Festival[] = [
    {
      id: "diwali",
      name: "Diwali Dhamaka",
      emoji: "🪔",
      date: "October 24, 2025",
      description: "Light up your child's world with sparkling toy deals",
      discount: 40,
      color: "from-yellow-400 to-orange-500",
      bgGradient: "from-yellow-400/20 to-orange-500/20",
      specialOffers: ["Free gift wrapping", "Extra 5% on prepaid", "Lucky draw prizes"],
      countdownDate: new Date("2025-10-24"),
    },
    {
      id: "holi",
      name: "Holi Hungama",
      emoji: "🎨",
      date: "March 13, 2025",
      description: "Colorful toys for the festival of colors",
      discount: 35,
      color: "from-pink-400 to-purple-500",
      bgGradient: "from-pink-400/20 to-purple-500/20",
      specialOffers: ["Color-safe toys", "Outdoor play sets", "Art & craft kits"],
      countdownDate: new Date("2025-03-13"),
    },
    {
      id: "rakhi",
      name: "Rakhi Revelry",
      emoji: "🎁",
      date: "August 11, 2025",
      description: "Perfect gifts for your precious siblings",
      discount: 30,
      color: "from-red-400 to-pink-500",
      bgGradient: "from-red-400/20 to-pink-500/20",
      specialOffers: ["Sibling combo packs", "Personalized gifts", "Express delivery"],
      countdownDate: new Date("2025-08-11"),
    },
  ];

  useEffect(() => {
    console.log("Setting up festival countdown timers");
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const newTimeLeft: typeof timeLeft = {};

      festivals.forEach(festival => {
        const distance = festival.countdownDate.getTime() - now;
        
        if (distance > 0) {
          newTimeLeft[festival.id] = {
            days: Math.floor(distance / (1000 * 60 * 60 * 24)),
            hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
            minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
            seconds: Math.floor((distance % (1000 * 60)) / 1000),
          };
        } else {
          newTimeLeft[festival.id] = { days: 0, hours: 0, minutes: 0, seconds: 0 };
        }
      });

      setTimeLeft(newTimeLeft);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Get the next upcoming festival
  const upcomingFestival = festivals.reduce((closest, festival) => {
    const now = new Date();
    const festivalDate = festival.countdownDate;
    const closestDate = closest.countdownDate;
    
    if (festivalDate > now && (festivalDate < closestDate || closestDate <= now)) {
      return festival;
    }
    return closest;
  }, festivals[0]);

  return (
    <section className="py-20 bg-gradient-to-b from-background to-secondary/5" id="festivals">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center justify-center mb-4">
            <Calendar className="h-8 w-8 text-primary mr-3 animate-pulse" />
            <h2 className="text-4xl md:text-5xl font-bold font-orbitron">
              <span className="gradient-text">Festival</span> Celebrations
            </h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Celebrate every festival with special toy collections and amazing deals. 
            Make every occasion memorable with ToySpark's festive magic!
          </p>
        </motion.div>

        {/* Featured Festival Countdown */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <Card className={`glass border-primary/20 overflow-hidden bg-gradient-to-r ${upcomingFestival.bgGradient}`}>
            <CardContent className="p-8 md:p-12">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="flex items-center mb-4">
                    <span className="text-6xl mr-4 animate-bounce">{upcomingFestival.emoji}</span>
                    <div>
                      <h3 className="text-3xl font-bold font-orbitron mb-2">
                        {upcomingFestival.name}
                      </h3>
                      <p className="text-muted-foreground">
                        {upcomingFestival.description}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {upcomingFestival.specialOffers.map((offer, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        <Gift className="w-3 h-3 mr-1" />
                        {offer}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center gap-4">
                    <Badge className={`text-lg px-4 py-2 bg-gradient-to-r ${upcomingFestival.color} text-white animate-pulse`}>
                      UP TO {upcomingFestival.discount}% OFF
                    </Badge>
                    <Button variant="outline" className="glass">
                      Shop Now
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Countdown Timer */}
                <div className="text-center">
                  <div className="flex items-center justify-center mb-4">
                    <Timer className="h-6 w-6 text-primary mr-2" />
                    <span className="text-lg font-semibold">Sale Ends In:</span>
                  </div>
                  
                  {timeLeft[upcomingFestival.id] && (
                    <div className="grid grid-cols-4 gap-4">
                      {[
                        { label: "Days", value: timeLeft[upcomingFestival.id]?.days },
                        { label: "Hours", value: timeLeft[upcomingFestival.id]?.hours },
                        { label: "Minutes", value: timeLeft[upcomingFestival.id]?.minutes },
                        { label: "Seconds", value: timeLeft[upcomingFestival.id]?.seconds },
                      ].map((time, index) => (
                        <motion.div
                          key={time.label}
                          className="glass rounded-lg p-4 border border-primary/20"
                          animate={{ scale: time.label === "Seconds" ? [1, 1.05, 1] : 1 }}
                          transition={{ duration: 1, repeat: Infinity }}
                        >
                          <div className="text-2xl md:text-3xl font-bold text-primary">
                            {String(time.value || 0).padStart(2, '0')}
                          </div>
                          <div className="text-xs text-muted-foreground uppercase tracking-wide">
                            {time.label}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* All Festivals Grid */}
        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          {festivals.map((festival, index) => (
            <motion.div
              key={festival.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="group cursor-pointer"
            >
              <Card className={`h-full glass border-primary/20 hover:border-primary/40 transition-all duration-300 overflow-hidden bg-gradient-to-br ${festival.bgGradient}`}>
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <motion.div
                      className="text-6xl mb-4"
                      animate={{ 
                        scale: [1, 1.1, 1],
                        rotate: [0, 5, -5, 0] 
                      }}
                      transition={{ 
                        duration: 3, 
                        repeat: Infinity,
                        delay: index * 0.5 
                      }}
                    >
                      {festival.emoji}
                    </motion.div>
                    <h3 className="text-xl font-bold mb-2">{festival.name}</h3>
                    <p className="text-muted-foreground text-sm mb-4">
                      {festival.description}
                    </p>
                    <Badge variant="secondary" className="text-xs">
                      {festival.date}
                    </Badge>
                  </div>

                  <div className="space-y-3 mb-6">
                    {festival.specialOffers.map((offer, offerIndex) => (
                      <div key={offerIndex} className="flex items-center text-sm">
                        <Sparkles className="w-4 h-4 text-primary mr-2 flex-shrink-0" />
                        <span>{offer}</span>
                      </div>
                    ))}
                  </div>

                  <div className="text-center">
                    <Badge className={`text-lg px-6 py-2 bg-gradient-to-r ${festival.color} text-white`}>
                      {festival.discount}% OFF
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Newsletter Signup */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <Card className="glass border-primary/20 max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">
                Never Miss Festival Deals! 🎉
              </h3>
              <p className="text-muted-foreground mb-6">
                Get early access to festival sales, exclusive discounts, and special gift collections.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <input
                  type="email"
                  placeholder="Enter your email address"
                  className="flex-1 px-4 py-3 rounded-lg border border-primary/20 bg-background/50 focus:border-primary focus:outline-none"
                />
                <Button className="shadow-neon">
                  <Gift className="mr-2 h-4 w-4" />
                  Subscribe Now
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}