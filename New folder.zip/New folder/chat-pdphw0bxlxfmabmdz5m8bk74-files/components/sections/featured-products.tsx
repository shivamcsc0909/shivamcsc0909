"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Heart, Star, Zap, Shield, Clock } from "lucide-react";
import { useState } from "react";

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  image: string;
  ageRange: string;
  rating: number;
  reviews: number;
  description: string;
  features: string[];
  isNew?: boolean;
  isFestival?: boolean;
  discount?: number;
}

export function FeaturedProducts() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  console.log("FeaturedProducts render - selectedCategory:", selectedCategory);

  const categories = [
    { id: "all", name: "All Toys", icon: "🎯" },
    { id: "rc", name: "RC Cars", icon: "🚗" },
    { id: "stem", name: "STEM Kits", icon: "🔬" },
    { id: "soft", name: "Soft Toys", icon: "🧸" },
    { id: "outdoor", name: "Outdoor", icon: "⚽" },
  ];

  const products: Product[] = [
    {
      id: "1",
      name: "Thunder Drift RC Car",
      category: "rc",
      price: 2499,
      originalPrice: 3499,
      image: "🚗",
      ageRange: "8-14",
      rating: 4.8,
      reviews: 127,
      description: "Professional drift car with 4WD and LED underglow",
      features: ["4WD System", "LED Lights", "1:14 Scale", "2.4GHz Remote"],
      isNew: true,
      discount: 29,
    },
    {
      id: "2",
      name: "Robo Builder Advanced",
      category: "stem",
      price: 4299,
      originalPrice: 5999,
      image: "🤖",
      ageRange: "10+",
      rating: 4.9,
      reviews: 89,
      description: "Build and program your own robot with sensors",
      features: ["Visual Coding", "16 Sensors", "Mobile App", "Voice Control"],
      isFestival: true,
      discount: 28,
    },
    {
      id: "3",
      name: "Cuddle Panda Premium",
      category: "soft",
      price: 1299,
      originalPrice: 1899,
      image: "🐼",
      ageRange: "2+",
      rating: 4.7,
      reviews: 234,
      description: "Ultra-soft organic cotton panda with heartbeat",
      features: ["Organic Cotton", "Heartbeat Sound", "Washable", "Hypoallergenic"],
      discount: 32,
    },
    {
      id: "4",
      name: "Sky Explorer Drone",
      category: "rc",
      price: 3299,
      originalPrice: 4499,
      image: "🚁",
      ageRange: "12+",
      rating: 4.6,
      reviews: 156,
      description: "HD camera drone with obstacle avoidance",
      features: ["HD Camera", "Auto Hover", "LED Lights", "App Control"],
      isNew: true,
      discount: 27,
    },
    {
      id: "5",
      name: "Chemistry Lab Deluxe",
      category: "stem",
      price: 2799,
      originalPrice: 3799,
      image: "🧪",
      ageRange: "8-15",
      rating: 4.8,
      reviews: 93,
      description: "50+ safe experiments with digital microscope",
      features: ["50+ Experiments", "Digital Microscope", "Safety Kit", "Guide Book"],
      discount: 26,
    },
    {
      id: "6",
      name: "Soccer Champion Set",
      category: "outdoor",
      price: 1599,
      originalPrice: 2299,
      image: "⚽",
      ageRange: "5-12",
      rating: 4.5,
      reviews: 178,
      description: "Complete soccer training set with smart ball",
      features: ["Smart Ball", "Training Cones", "Goal Posts", "Skill Tracker"],
      discount: 30,
    },
  ];

  const filteredProducts = selectedCategory === "all" 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  return (
    <section className="py-20 bg-gradient-to-b from-primary/5 to-background" id="featured-products">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold font-orbitron mb-6">
            <span className="gradient-text">Featured</span> Collection
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Handpicked premium toys that combine fun, learning, and safety. 
            Each product is crafted with international quality standards.
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          {categories.map((category, index) => (
            <motion.button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                selectedCategory === category.id
                  ? "bg-primary text-primary-foreground shadow-neon"
                  : "glass hover:bg-primary/10 border border-primary/20"
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <span className="mr-2">{category.icon}</span>
              {category.name}
            </motion.button>
          ))}
        </motion.div>

        {/* Products Grid */}
        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          layout
        >
          {filteredProducts.map((product, index) => (
            <motion.div
              key={product.id}
              layout
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group"
            >
              <Card className="h-full glass border-primary/20 hover:border-primary/40 transition-all duration-300 overflow-hidden">
                <div className="relative">
                  {/* Product Image */}
                  <div className="bg-gradient-to-br from-primary/20 to-secondary/20 p-8 relative">
                    <div className="text-8xl text-center animate-float group-hover:scale-110 transition-transform duration-300">
                      {product.image}
                    </div>
                    
                    {/* Badges */}
                    <div className="absolute top-4 left-4 flex flex-col gap-2">
                      {product.isNew && (
                        <Badge className="bg-neon-cyan text-deep-space animate-pulse">
                          <Zap className="w-3 h-3 mr-1" />
                          New!
                        </Badge>
                      )}
                      {product.isFestival && (
                        <Badge className="bg-electric-pink text-white animate-pulse">
                          🎉 Festival
                        </Badge>
                      )}
                      {product.discount && (
                        <Badge variant="destructive" className="animate-pulse">
                          -{product.discount}%
                        </Badge>
                      )}
                    </div>

                    {/* Wishlist Button */}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute top-4 right-4 glass opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>

                  <CardContent className="p-6">
                    {/* Product Info */}
                    <div className="mb-4">
                      <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-3">
                        {product.description}
                      </p>
                      
                      {/* Rating & Age */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                          <span className="font-medium">{product.rating}</span>
                          <span className="text-muted-foreground text-sm ml-1">
                            ({product.reviews})
                          </span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          <Clock className="w-3 h-3 mr-1" />
                          {product.ageRange} years
                        </Badge>
                      </div>
                    </div>

                    {/* Features */}
                    <div className="mb-4 space-y-1">
                      {product.features.slice(0, 3).map((feature, idx) => (
                        <div key={idx} className="flex items-center text-xs text-muted-foreground">
                          <Shield className="w-3 h-3 mr-2 text-primary" />
                          {feature}
                        </div>
                      ))}
                    </div>

                    {/* Price & CTA */}
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-primary">
                            ₹{product.price.toLocaleString()}
                          </span>
                          {product.originalPrice > product.price && (
                            <span className="text-sm text-muted-foreground line-through">
                              ₹{product.originalPrice.toLocaleString()}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Free shipping above ₹999
                        </div>
                      </div>
                      
                      <Button
                        size="sm"
                        className="shadow-lg group-hover:shadow-neon transition-shadow"
                      >
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Add to Cart
                      </Button>
                    </div>
                  </CardContent>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* View All Button */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
        >
          <Button size="lg" variant="outline" className="glass group">
            View All Products
            <motion.div
              className="ml-2"
              animate={{ x: [0, 5, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              →
            </motion.div>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}