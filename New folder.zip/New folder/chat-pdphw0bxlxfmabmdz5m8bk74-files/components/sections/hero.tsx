"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Zap, Heart, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function Hero() {
  console.log("Hero component rendering");

  const floatingToys = [
    { icon: "🚗", delay: 0 },
    { icon: "🚁", delay: 0.5 },
    { icon: "🧸", delay: 1 },
    { icon: "🎯", delay: 1.5 },
    { icon: "🎮", delay: 2 },
    { icon: "⚡", delay: 2.5 },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-background via-background/95 to-primary/5">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        {floatingToys.map((toy, index) => (
          <motion.div
            key={index}
            className="absolute text-4xl opacity-20"
            initial={{ 
              x: Math.random() * 800,
              y: Math.random() * 600,
              rotate: 0,
            }}
            animate={{
              y: [null, -50, 0],
              rotate: [0, 360],
              x: [null, Math.random() * 100 - 50],
            }}
            transition={{
              duration: 6 + Math.random() * 4,
              repeat: Infinity,
              delay: toy.delay,
              ease: "easeInOut",
            }}
          >
            {toy.icon}
          </motion.div>
        ))}
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Content */}
          <motion.div
            className="text-center lg:text-left"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mb-6"
            >
              <Badge variant="secondary" className="text-sm px-4 py-2 animate-pulse">
                <Zap className="w-4 h-4 mr-2" />
                Premium Indian Manufacturing
              </Badge>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              className="text-5xl md:text-7xl font-bold font-orbitron mb-6 leading-tight"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              <span className="gradient-text">Next-Gen</span>
              <br />
              <span className="text-foreground">Toy Experience</span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              className="text-xl text-muted-foreground mb-8 max-w-md mx-auto lg:mx-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              Discover premium self-manufactured toys with AI-powered age recommendations. 
              From RC cars to STEM kits - bringing international quality to Indian families.
            </motion.p>

            {/* Stats */}
            <motion.div
              className="flex flex-wrap justify-center lg:justify-start gap-6 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              {[
                { icon: Heart, value: "10k+", label: "Happy Families" },
                { icon: Star, value: "4.9", label: "Rating" },
                { icon: Zap, value: "100%", label: "Safe & Tested" },
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="flex items-center justify-center mb-1">
                    <stat.icon className="w-4 h-4 text-primary mr-1" />
                    <span className="text-2xl font-bold text-primary">{stat.value}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">{stat.label}</span>
                </div>
              ))}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <Button size="lg" className="group relative overflow-hidden shadow-neon">
                <span className="relative z-10 flex items-center">
                  Find Perfect Toy
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Button>
              
              <Button variant="outline" size="lg" className="group glass">
                <Play className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
                Watch Demo
              </Button>
            </motion.div>
          </motion.div>

          {/* Right Content - Featured Product Showcase */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative">
              {/* Main Product Card */}
              <motion.div
                className="glass rounded-3xl p-8 shadow-2xl"
                whileHover={{ scale: 1.02, rotateY: 5 }}
                transition={{ duration: 0.3 }}
              >
                <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl p-6 mb-6">
                  <div className="text-6xl text-center animate-float">🚗</div>
                </div>
                
                <h3 className="text-2xl font-bold mb-2">Premium RC Racer</h3>
                <p className="text-muted-foreground mb-4">
                  Professional-grade remote control car with 360° stunts capability
                </p>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm text-muted-foreground">Age Range</span>
                    <div className="text-primary font-semibold">8-12 years</div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm text-muted-foreground line-through">₹2,999</span>
                    <div className="text-2xl font-bold text-primary">₹1,999</div>
                  </div>
                </div>
              </motion.div>

              {/* Floating Elements */}
              <motion.div
                className="absolute -top-4 -right-4 glass rounded-full p-4 shadow-lg"
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <Badge variant="secondary" className="animate-pulse">
                  Festival Sale!
                </Badge>
              </motion.div>
              
              <motion.div
                className="absolute -bottom-4 -left-4 glass rounded-full p-3"
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <Star className="h-6 w-6 text-primary" />
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center">
          <div className="w-1 h-3 bg-primary rounded-full mt-2 animate-pulse" />
        </div>
      </motion.div>
    </section>
  );
}