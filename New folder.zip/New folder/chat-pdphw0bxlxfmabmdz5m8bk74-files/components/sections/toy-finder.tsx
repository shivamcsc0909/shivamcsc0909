"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, ArrowLeft, Sparkles, Baby, GraduationCap, Zap, Heart } from "lucide-react";

interface ToyRecommendation {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  image: string;
  ageRange: string;
  description: string;
  features: string[];
  safetyRating: number;
}

export function ToyFinder() {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedAge, setSelectedAge] = useState<number | null>(null);
  const [selectedInterest, setSelectedInterest] = useState<string | null>(null);
  const [selectedBudget, setSelectedBudget] = useState<string | null>(null);
  const [recommendations, setRecommendations] = useState<ToyRecommendation[]>([]);

  console.log("ToyFinder render - currentStep:", currentStep, "selectedAge:", selectedAge);

  const ageRanges = [
    { range: "0-3", label: "Toddler", icon: Baby, description: "Sensory & Motor Skills" },
    { range: "4-6", label: "Preschool", icon: Heart, description: "Learning & Creativity" },
    { range: "7-9", label: "School Age", icon: GraduationCap, description: "Problem Solving" },
    { range: "10+", label: "Tweens", icon: Zap, description: "Advanced & Technical" },
  ];

  const interests = [
    { id: "rc", name: "Remote Control", emoji: "🚗", description: "Cars, drones, robots" },
    { id: "stem", name: "STEM Learning", emoji: "🔬", description: "Science, coding, building" },
    { id: "creative", name: "Creative Arts", emoji: "🎨", description: "Drawing, crafts, music" },
    { id: "physical", name: "Active Play", emoji: "⚽", description: "Sports, outdoor, movement" },
    { id: "soft", name: "Soft Toys", emoji: "🧸", description: "Plush, dolls, comfort" },
  ];

  const budgetRanges = [
    { id: "budget", label: "Under ₹1,000", range: "0-1000" },
    { id: "mid", label: "₹1,000 - ₹3,000", range: "1000-3000" },
    { id: "premium", label: "₹3,000 - ₹5,000", range: "3000-5000" },
    { id: "luxury", label: "Above ₹5,000", range: "5000+" },
  ];

  const generateRecommendations = () => {
    console.log("Generating recommendations for:", { selectedAge, selectedInterest, selectedBudget });
    
    // Mock recommendation logic
    const mockRecommendations: ToyRecommendation[] = [
      {
        id: "1",
        name: "Lightning RC Stunt Car",
        category: "Remote Control",
        price: 1899,
        originalPrice: 2499,
        image: "🚗",
        ageRange: "8-12 years",
        description: "360° flip stunts with LED lights and sound effects",
        features: ["Waterproof", "2.4GHz Control", "Rechargeable Battery"],
        safetyRating: 4.8,
      },
      {
        id: "2",
        name: "STEM Robot Builder Kit",
        category: "Educational",
        price: 2999,
        originalPrice: 3999,
        image: "🤖",
        ageRange: "10+ years",
        description: "Build and program your own robot with visual coding",
        features: ["Visual Programming", "Sensors", "Mobile App Control"],
        safetyRating: 4.9,
      },
      {
        id: "3",
        name: "Cuddle Bear Deluxe",
        category: "Soft Toys",
        price: 899,
        originalPrice: 1299,
        image: "🧸",
        ageRange: "3+ years",
        description: "Ultra-soft premium plush with interactive sounds",
        features: ["Hypoallergenic", "Machine Washable", "Voice Recording"],
        safetyRating: 4.7,
      },
    ];

    setRecommendations(mockRecommendations);
    setCurrentStep(4);
  };

  const resetWizard = () => {
    console.log("Resetting toy finder wizard");
    setCurrentStep(0);
    setSelectedAge(null);
    setSelectedInterest(null);
    setSelectedBudget(null);
    setRecommendations([]);
  };

  const steps = [
    {
      title: "What's the child's age?",
      subtitle: "We'll recommend age-appropriate toys for safety and development",
    },
    {
      title: "What interests them most?",
      subtitle: "Help us understand their play preferences and learning style",
    },
    {
      title: "What's your budget?",
      subtitle: "Find the perfect toy within your price range",
    },
    {
      title: "Review & Find Toys",
      subtitle: "Confirm your preferences and discover perfect matches",
    },
    {
      title: "Perfect Matches Found!",
      subtitle: "Here are toys specially curated for your needs",
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="h-8 w-8 text-primary mr-3 animate-pulse" />
            <h2 className="text-4xl md:text-5xl font-bold font-orbitron gradient-text">
              Smart Toy Finder
            </h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Answer 3 simple questions and get AI-powered toy recommendations 
            perfectly matched to your child's age, interests, and your budget
          </p>
        </motion.div>

        {/* Progress Bar */}
        <motion.div
          className="mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex justify-center mb-4">
            <div className="flex space-x-2">
              {steps.map((_, index) => (
                <motion.div
                  key={index}
                  className={`h-2 w-12 rounded-full transition-colors duration-300 ${
                    index <= currentStep ? "bg-primary" : "bg-muted"
                  }`}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: index <= currentStep ? 1 : 0.3 }}
                  transition={{ delay: index * 0.1 }}
                />
              ))}
            </div>
          </div>
          <p className="text-center text-sm text-muted-foreground">
            Step {currentStep + 1} of {steps.length}
          </p>
        </motion.div>

        {/* Wizard Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="max-w-4xl mx-auto"
          >
            <Card className="glass border-primary/20">
              <CardHeader className="text-center pb-8">
                <h3 className="text-2xl font-bold mb-2">{steps[currentStep].title}</h3>
                <p className="text-muted-foreground">{steps[currentStep].subtitle}</p>
              </CardHeader>
              
              <CardContent>
                {/* Step 0: Age Selection */}
                {currentStep === 0 && (
                  <div className="grid md:grid-cols-2 gap-4">
                    {ageRanges.map((age, index) => {
                      const IconComponent = age.icon;
                      return (
                        <motion.button
                          key={age.range}
                          className={`p-6 rounded-xl border-2 transition-all duration-200 text-left ${
                            selectedAge === index
                              ? "border-primary bg-primary/10 shadow-lg"
                              : "border-border hover:border-primary/50"
                          }`}
                          onClick={() => setSelectedAge(index)}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <div className="flex items-center mb-3">
                            <IconComponent className="h-6 w-6 text-primary mr-3" />
                            <div>
                              <h4 className="font-semibold">{age.label}</h4>
                              <span className="text-sm text-muted-foreground">{age.range} years</span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{age.description}</p>
                        </motion.button>
                      );
                    })}
                  </div>
                )}

                {/* Step 1: Interest Selection */}
                {currentStep === 1 && (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {interests.map((interest, index) => (
                      <motion.button
                        key={interest.id}
                        className={`p-6 rounded-xl border-2 transition-all duration-200 text-center ${
                          selectedInterest === interest.id
                            ? "border-primary bg-primary/10 shadow-lg"
                            : "border-border hover:border-primary/50"
                        }`}
                        onClick={() => setSelectedInterest(interest.id)}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <div className="text-4xl mb-3">{interest.emoji}</div>
                        <h4 className="font-semibold mb-2">{interest.name}</h4>
                        <p className="text-sm text-muted-foreground">{interest.description}</p>
                      </motion.button>
                    ))}
                  </div>
                )}

                {/* Step 2: Budget Selection */}
                {currentStep === 2 && (
                  <div className="grid md:grid-cols-2 gap-4">
                    {budgetRanges.map((budget, index) => (
                      <motion.button
                        key={budget.id}
                        className={`p-6 rounded-xl border-2 transition-all duration-200 text-center ${
                          selectedBudget === budget.id
                            ? "border-primary bg-primary/10 shadow-lg"
                            : "border-border hover:border-primary/50"
                        }`}
                        onClick={() => setSelectedBudget(budget.id)}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <h4 className="font-semibold text-lg">{budget.label}</h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          Perfect for {budget.id} range toys
                        </p>
                      </motion.button>
                    ))}
                  </div>
                )}

                {/* Step 3: Review */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <h4 className="font-semibold mb-2">Age Range</h4>
                        <Badge variant="secondary" className="text-sm">
                          {selectedAge !== null ? ageRanges[selectedAge].label : "Not selected"}
                        </Badge>
                      </div>
                      <div className="text-center">
                        <h4 className="font-semibold mb-2">Interest</h4>
                        <Badge variant="secondary" className="text-sm">
                          {selectedInterest ? interests.find(i => i.id === selectedInterest)?.name : "Not selected"}
                        </Badge>
                      </div>
                      <div className="text-center">
                        <h4 className="font-semibold mb-2">Budget</h4>
                        <Badge variant="secondary" className="text-sm">
                          {selectedBudget ? budgetRanges.find(b => b.id === selectedBudget)?.label : "Not selected"}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <Button 
                        size="lg" 
                        onClick={generateRecommendations}
                        className="shadow-neon"
                        disabled={!selectedAge || !selectedInterest || !selectedBudget}
                      >
                        <Sparkles className="mr-2 h-4 w-4" />
                        Find Perfect Toys
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step 4: Results */}
                {currentStep === 4 && (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {recommendations.map((toy, index) => (
                        <motion.div
                          key={toy.id}
                          initial={{ opacity: 0, y: 30 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.2 }}
                        >
                          <Card className="hover:shadow-lg transition-shadow">
                            <CardContent className="p-6">
                              <div className="text-6xl text-center mb-4">{toy.image}</div>
                              <h4 className="font-semibold text-lg mb-2">{toy.name}</h4>
                              <p className="text-sm text-muted-foreground mb-3">{toy.description}</p>
                              
                              <div className="flex items-center justify-between mb-4">
                                <div>
                                  <span className="text-lg font-bold text-primary">₹{toy.price}</span>
                                  <span className="text-sm text-muted-foreground line-through ml-2">
                                    ₹{toy.originalPrice}
                                  </span>
                                </div>
                                <Badge variant="outline">{toy.ageRange}</Badge>
                              </div>
                              
                              <div className="space-y-2 mb-4">
                                {toy.features.map((feature, idx) => (
                                  <div key={idx} className="text-xs text-muted-foreground">
                                    • {feature}
                                  </div>
                                ))}
                              </div>
                              
                              <Button className="w-full">
                                Add to Cart
                                <ArrowRight className="ml-2 h-4 w-4" />
                              </Button>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                    
                    <div className="text-center">
                      <Button variant="outline" onClick={resetWizard}>
                        Find More Toys
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        {currentStep < 4 && (
          <motion.div
            className="flex justify-between mt-8 max-w-4xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <Button
              variant="outline"
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
              className="glass"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            
            <Button
              onClick={() => setCurrentStep(currentStep + 1)}
              disabled={
                (currentStep === 0 && selectedAge === null) ||
                (currentStep === 1 && selectedInterest === null) ||
                (currentStep === 2 && selectedBudget === null)
              }
            >
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </motion.div>
        )}
      </div>
    </section>
  );
}